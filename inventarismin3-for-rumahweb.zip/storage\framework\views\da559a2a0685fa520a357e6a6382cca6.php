<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title', null, []); ?> Halaman Peminjaman <?php $__env->endSlot(); ?>
	 <?php $__env->slot('page_heading', null, []); ?> Peminjaman <?php $__env->endSlot(); ?>

	<div class="card">
		<div class="card-body">
			<?php echo $__env->make('utilities.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="d-flex justify-content-end mb-3">
				<div class="btn-group">
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('import peminjaman')): ?>
					<button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target="#excel_menu">
						<i class="fas fa-fw fa-upload"></i>
						Import Excel
					</button>
					<?php endif; ?>

					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export peminjaman')): ?>
					<form action="<?php echo e(route('peminjaman.export', 'masuk')); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<button type="submit" class="btn btn-success mr-2">
							<i class="fas fa-fw fa-download"></i>
							Export Excel
						</button>
					</form>
					<?php endif; ?>

					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tambah peminjaman')): ?>
					<button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target="#item_loan_create_modal">
						<i class="fas fa-fw fa-plus"></i>
						Tambah Data
					</button>
					<?php endif; ?>
				</div>
			</div>

			<!-- Search Bar -->
			<div class="row mb-3">
				<div class="col-md-6">
					<form method="GET" action="<?php echo e(route('peminjaman.barang-masuk')); ?>">
						<div class="input-group">
							<input type="text" class="form-control" name="search" placeholder="Cari nama peminjam, nomor HP, nama barang, atau kode barang..." value="<?php echo e(request('search')); ?>">
							<div class="input-group-append">
								<button class="btn btn-primary" type="submit">
									<i class="fas fa-search"></i>
								</button>
							</div>
						</div>
					</form>
				</div>
			</div>

			<div class="table-responsive">
				<table class="table table-striped" id="table-1">
					<thead>
						<tr>
							<th>No</th>
							<th>Kode Barang</th>
							<th>Nama Barang</th>
							<th>Nama Peminjam</th>
							<th>Nomor HP</th>
							<th>Tanggal Pinjam</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $item_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item_loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($index + 1); ?></td>
							<td><?php echo e($item_loan->item_code); ?></td>
							<td><?php echo e($item_loan->item_name); ?></td>
							<td><?php echo e($item_loan->borrower_name); ?></td>
							<td><?php echo e($item_loan->phone_number); ?></td>
							<td><?php echo e($item_loan->indonesian_format_date($item_loan->loan_date)); ?></td>
							<td>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ubah peminjaman')): ?>
								<button data-id="<?php echo e($item_loan->id); ?>" class="btn btn-warning btn-sm edit-modal" data-toggle="modal" data-target="#item_loan_edit_modal">
									<i class="fas fa-edit"></i>
								</button>
								<?php endif; ?>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hapus peminjaman')): ?>
								<form action="<?php echo e(route('peminjaman.destroy', $item_loan->id)); ?>" method="POST" class="d-inline delete-form">
									<?php echo csrf_field(); ?>
									<?php echo method_field('DELETE'); ?>
									<button type="submit" class="btn btn-danger btn-sm delete-button">
										<i class="fas fa-trash"></i>
									</button>
								</form>
								<?php endif; ?>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td colspan="7" class="text-center">Tidak ada data</td>
						</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!-- Create Modal -->
	<?php echo $__env->make('item-loans.modal.create', ['status' => 'masuk'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Edit Modal -->
	<?php echo $__env->make('item-loans.modal.edit', ['status' => 'masuk'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Excel Import Modal -->
	<?php echo $__env->make('item-loans.modal.excel-import', ['status' => 'masuk'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('item-loans._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\inventarissekolahku\resources\views/item-loans/barang-masuk.blade.php ENDPATH**/ ?>