<?php if($errors->store->any()): ?>
<div class="alert alert-light alert-dismissible fade show border border-danger" role="alert">
	<strong>
		<i class="fas fa-exclamation"></i>
		Data gagal ditambahkan!
	</strong>

	<ul>
		<?php $__currentLoopData = $errors->store->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($message); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<?php endif; ?>

<?php if($errors->update->any()): ?>
<div class="alert alert-light alert-dismissible fade show border border-danger" role="alert">
	<strong>
		<i class="fas fa-exclamation"></i>
		Data gagal diubah!
	</strong>

	<ul>
		<?php $__currentLoopData = $errors->update->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($message); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<?php endif; ?>

<?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
	<strong>
		<i class="fas fa-thumbs-up"></i>
		Berhasil!
	</strong> <?php echo e(session('success')); ?>

	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
	<strong>
		<i class="fas fa-thumbs-down"></i>
		Gagal!
	</strong> <?php echo e(session('error')); ?>

	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
<?php /**PATH C:\Users\USER\Downloads\Compressed\inven-bs-main\resources\views/utilities/alert.blade.php ENDPATH**/ ?>