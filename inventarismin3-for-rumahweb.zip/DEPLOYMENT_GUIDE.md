# Panduan Deployment ke RumahWeb

## Persiapan Sebelum Upload

### 1. Generate Application Key
```bash
php artisan key:generate
```

### 2. Optimize Laravel untuk Production
```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### 3. File yang Perlu Diupload ke RumahWeb

**Upload semua file kecuali:**
- `.git/` folder
- `node_modules/` folder (jika ada)
- `.env` file (akan dibuat manual di server)
- `storage/logs/` folder (akan dibuat otomatis)

## Langkah-langkah Upload ke RumahWeb

### 1. Login ke cPanel RumahWeb
- Buka cPanel dari dashboard RumahWeb
- Login dengan username dan password yang diberikan

### 2. Upload File
- Buka **File Manager**
- Navigasi ke folder `public_html` atau folder yang ditentukan
- Upload semua file proyek Laravel

### 3. Konfigurasi Database
- Buka **MySQL Databases** di cPanel
- Buat database baru
- Buat user database
- Assign user ke database
- Import file `inventarissekolahku.sql`

### 4. Konfigurasi Environment
- Buat file `.env` di root folder
- Sesuaikan konfigurasi database:
```
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=nama_database_anda
DB_USERNAME=username_database_anda
DB_PASSWORD=password_database_anda
```

### 5. Set Permission Folder
Set permission folder berikut menjadi 755:
- `storage/`
- `bootstrap/cache/`

### 6. Jalankan Migration (jika diperlukan)
```bash
php artisan migrate
```

### 7. Clear Cache
```bash
php artisan config:clear
php artisan cache:clear
php artisan view:clear
```

## Troubleshooting

### Error 500
- Periksa file `.env` sudah benar
- Periksa permission folder `storage` dan `bootstrap/cache`
- Periksa error log di cPanel

### Database Connection Error
- Periksa konfigurasi database di `.env`
- Pastikan database sudah dibuat dan user memiliki akses

### File Not Found
- Pastikan semua file sudah terupload dengan benar
- Periksa struktur folder di server

## Kontak Support
Jika mengalami masalah, hubungi support RumahWeb atau konsultasikan dengan tim development.
