<div class="modal fade" id="excel_menu" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog"
	aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modalLabel">Import Excel <?php echo e($status === 'masuk' ? 'Peminjaman' : 'Pengembalian'); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>

			<div class="modal-body">
				<form action="<?php echo e(route('peminjaman.import', $status)); ?>" method="POST" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label for="file">Pilih File Excel</label>
						<input type="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file" id="file"
							accept=".xlsx,.xls">
						<?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="d-block invalid-feedback">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>

					<div class="alert alert-info">
						<h6>Format Excel yang dibutuhkan:</h6>
						<ul class="mb-0">
							<li><strong>nama_peminjam</strong> - Nama peminjam barang</li>
							<li><strong>nomor_hp</strong> - Nomor HP peminjam</li>
							<li><strong>nama_barang</strong> - Nama barang yang dipinjam</li>
							<li><strong>kode_barang</strong> - Kode barang</li>
							<li><strong>tanggal_peminjaman</strong> - Tanggal peminjaman</li>
							<?php if($status === 'keluar'): ?>
							<li><strong>tanggal_pengembalian</strong> - Tanggal pengembalian</li>
							<?php endif; ?>
							<li><strong>catatan</strong> - Catatan (opsional)</li>
						</ul>
						
						<hr>
						<p class="mb-0">
							<strong>Download Template:</strong>
							<?php if($status === 'masuk'): ?>
								<a href="<?php echo e(asset('template-peminjaman-barang-masuk.xlsx')); ?>" class="btn btn-sm btn-outline-primary">
									<i class="fas fa-download"></i> Template Peminjaman
								</a>
							<?php else: ?>
								<a href="<?php echo e(asset('template-peminjaman-barang-keluar.xlsx')); ?>" class="btn btn-sm btn-outline-primary">
									<i class="fas fa-download"></i> Template Pengembalian
								</a>
							<?php endif; ?>
						</p>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
						<button type="submit" class="btn btn-primary">Import</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php /**PATH C:\laragon\www\inventarissekolahku\resources\views/item-loans/modal/excel-import.blade.php ENDPATH**/ ?>